var express = require('express')
var router = express.Router()
var Compositor = require('../../controllers/api/compositor')
var url = require('url')

router.get('/',(req,res)=>{
    if(req.query.data && req.query.periodo){
        Compositor.consultarDataPeriodo(req.query)
            .then(dados => {
                res.jsonp(dados)
            })
            .catch(erro => {
                res.status(500).send('Erro ao consultar data e periodo.')
            })
    }
    else if(req.query.periodo){
        Compositor.consultarPeriodo(req.query.periodo)
            .then(dados => {
                res.jsonp(dados)
            })
            .catch(erro => {
                res.status(500).send('Erro ao consultar o periodo.')
            })
    }
    else{
        Compositor.listar()
        .then(dados => {
            res.jsonp(dados)
        })
        .catch(erro => {
            res.status(500).send('Erro a listar os compositores')
        })
    }
})

router.get('/:id',(req,res)=>{
    Compositor.consultar(req.params.id)
        .then(dados => {
            res.jsonp(dados)
        })
        .catch(erro => {
            res.status(500).send('Erro ao consultar um compositor')
        })
})

module.exports = router