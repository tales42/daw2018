var Compositor = require('../../models/compositor')

module.exports.listar = () => {
    return Compositor.find({},{_id:0,"@id":1,nome:1,dataNasc:1}).exec()
}

module.exports.consultar = compid => {
    return Compositor.findOne({"@id" : compid}).exec()
}

module.exports.consultarPeriodo = cperiodo => {
    return Compositor.find({periodo: cperiodo}).exec()
}

module.exports.consultarDataPeriodo = pedido => {
    return Compositor.find({periodo: pedido.periodo, dataNasc:{$gte: pedido.data}}).exec()
}