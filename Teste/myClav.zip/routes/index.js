var express = require('express');
var router = express.Router();
var axios = require('axios')


/* GET home page. */
router.get('/', function(req, res) {
  axios.get('http://clav-test.di.uminho.pt/api/classes/nivel/1')
    .then(dados => {
      res.render('index', {processos:dados.data})
    })
    .catch(erro => {
      res.render('error',{error:erro,message:"Occoreu um erro."})
    })
});

router.get('/nivel2/:cid',(req,res)=>{
  axios.get('http://clav-test.di.uminho.pt/api/classes/c' + req.params.cid +'/descendencia')
    .then(dados => {
      res.render('nivel2',{processos: dados.data, codigo:req.params.cid})
    })
    .catch(erro => {
      res.render('error',{error:erro,message:"Ocorreu um erro."})
    })
})

router.get('/nivel3/:cid',(req,res)=>{
  axios.get('http://clav-test.di.uminho.pt/api/classes/c' + req.params.cid + '/descendencia')
    .then(dados => {
      res.render('nivel3',{processos: dados.data, codigo:req.params.cid})
    })
    .catch(erro => {
      res.render('error',{error:erro,message:'Ocorreu um erro.'})
    })
})

router.get('/nivel4/:cid',(req,res)=>{
  axios.get('http://clav-test.di.uminho.pt/api/classes/c'+req.params.cid)
    .then(dados => {
      res.render('processo',{proc: dados.data[0]})
    })
    .catch(erro => {
      res.render('error',{error:erro,message:'Ocorreu um erro.'})
    })
})

module.exports = router;
